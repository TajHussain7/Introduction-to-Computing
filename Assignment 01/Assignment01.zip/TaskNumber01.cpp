#include<iostream>
using namespace std;
int main() {
	int num1;
	float num2;
	cout << "Enter an integer :" << " ";
	cin >> num1;
	cout << "Enter a float :" << " ";
	cin >> num2;
	cout << endl;
	cout << "Before swapping , the values are :" << endl << "Num 1 ="<<" " << num1 << " " << "and" << "  " << "Num 2 ="<<" "<< num2 << endl;
	cout << endl;
	cout << "After swapping , the values are :" << endl << "Num 1 ="<<" " << int(num2) << " " << "and" << "  " << "Num 2 ="<<" "<< num1 << endl;
	return 0;
}