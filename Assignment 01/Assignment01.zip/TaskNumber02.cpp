#include<iostream>
using namespace std;
int main() {
	float x;
	cout << "Enter the total amount of milk (liters) produced in ths morning : " << endl;
	cin >> x;
	//One Carton holds liters of milk = 3.78
	float y = 3.78;
	int result = 0;
	result = x / y;
	cout << "Number of cartons needed to hold milk :" << endl << result;
	cout << endl;
	//The cost of producing one liter of milk = $0.38
	float z = 0.38;
	int product = 0;
	product = x * z;
	cout << "Cost of milk producing :" << endl << "$" << product << endl;
	//Profit of each carton = $0.27
	float w = 0.27;
	int profit = 0;
	profit = w * result;
	cout << "Profit for producing milk :" << endl << "$" << profit;
	return 0;
	system("pause");
}