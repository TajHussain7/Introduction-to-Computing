#include<iostream>

using namespace std;
int main() {
	float percentage = 0;
	cout << "Please enter the percentage grade obtained by the student : ";
	cin >> percentage;

	if (percentage < 100 && percentage >= 90)
	{
		cout << "The student grade is A" << endl;
	}
	else if (percentage < 89 && percentage >= 80)
	{
		cout << "The student grade is B" << endl;
	}
	else if (percentage < 79 && percentage >= 70)
	{
		cout << "The student grade is C" << endl;
	}
	else if (percentage < 69 && percentage >= 60)
	{
		cout << "The student grade is D" << endl;
	}
	else if (percentage < 60)
	{
		cout << "The student grade is F" << endl;
	}
	else if (percentage > 100 && percentage < 0)
	{
		cout << "The grade is invalid. " << endl;
	}


	system("pause");
	return 0;
}