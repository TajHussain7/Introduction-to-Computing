#include<iostream>

using namespace std;

int main() {
	int n;
	cout << "Enter  positive integer : ";
	cin >> n;
	cout << "The prime numbers between 1 ane " << n << " are : " << endl;
	int p = 1;
	for (int i = 2; i <= n; i++)
	{
		for (int j = 2; j < i; j++)
		{
			if (i % j == 0)
			{
				p = 0;
				break;
			}
		}
		if (p == 1)
		{
			cout<<i<<endl;
		}
		p=1;
	}
	system("pause");
	return 0;
}