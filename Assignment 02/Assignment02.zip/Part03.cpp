#include<iostream>
using namespace std;
int main() {
	int num;
	cout << "Enter an integer : ";
	cin >> num;
	cout << endl << endl << endl;

	cout << "Expected output : " << endl << endl;
	if (num % 2 == 0)
	{
		cout << num << " is multiple of " << 2 << endl << endl;
	}
	if (num % 3 == 0)
	{
		cout << num << " is multiple of " << 3 << endl << endl;
	}
	if (num % 4 == 0)
	{
		cout << num << " is multiple of " << 4 << endl << endl;
	}
	if (num % 5 == 0)
	{
		cout << num << " is multiple of " << 5 << endl << endl;
	}

	cout << endl;



	system("pause");
	return 0;
}