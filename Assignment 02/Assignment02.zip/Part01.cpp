#include<iostream>

using namespace std;
int main() {
	int age;
	cout << "Enter your age : ";
	cin >> age;
	if (age >= 18)
	{
		cout << "Your are eligible to vote." << endl;
	}
	else {
		cout << "Sorry , you are not old  enough to vote yet." << endl;
	}
	cout << endl;

	system("pause");
	return 0;
}